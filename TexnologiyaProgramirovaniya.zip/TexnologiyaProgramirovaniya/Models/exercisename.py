from dataclasses import dataclass
@dataclass
class Exercise:
    id: int = None
    ExerciseName: str = None
    Classroom: int = None

        