from dataclasses import dataclass
@dataclass
class DayofweekExercisesDo:
    id: int = None
    ExerciseName: str = None
    Classroom: int = None
