from dataclasses import dataclass
@dataclass
class Dayofweek:
    id: int = None
    DayofweekName: str = None


